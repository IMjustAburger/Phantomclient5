@echo off
cd /d "%~dp0"
call gradlew.bat build %*
exit /b %ERRORLEVEL%
