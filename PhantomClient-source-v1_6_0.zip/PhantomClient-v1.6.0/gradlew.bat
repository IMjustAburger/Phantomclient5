@echo off
set "APP_HOME=%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Java 21 or newer is required. Install a Java 21 JDK and try again.
  exit /b 1
)
java %JAVA_OPTS% -Dphantom.projectDir="%APP_HOME%" -jar "%APP_HOME%gradle\wrapper\gradle-bootstrap.jar" %*
exit /b %ERRORLEVEL%
