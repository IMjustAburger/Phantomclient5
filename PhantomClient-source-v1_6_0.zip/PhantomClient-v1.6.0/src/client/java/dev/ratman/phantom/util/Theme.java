package dev.ratman.phantom.util;

import com.google.gson.JsonObject;

/** Global GUI/HUD theme. Persisted with the active profile. */
public final class Theme {
    public static final String[] PRESET_NAMES = {
            "Phantom", "Violet", "Orchid", "Magenta", "Indigo", "Rose", "Amethyst", "Ice"
    };
    public static final int[] PRESETS = {
            0xFFA855F7, 0xFF8B5CF6, 0xFFC084FC, 0xFFD946EF, 0xFF6366F1, 0xFFF472B6, 0xFF9333EA, 0xFF93C5FD
    };

    public static int preset = 0;
    public static boolean useCustom = false;
    public static int custom = 0xFFA855F7;
    public static boolean rainbow = false;
    public static float panelOpacity = 0.94f;
    public static float animSpeed = 1.0f;
    public static int cornerRadius = 3;

    public static final int BG_DEEP = 0xFF07040D;
    public static final int PANEL = 0xFF0F0A1A;
    public static final int PANEL_HEADER = 0xFF160E26;
    public static final int ROW = 0xFF130D20;
    public static final int ROW_HOVER = 0xFF1D1330;
    public static final int BORDER = 0xFF2B1D47;
    public static final int TEXT = 0xFFF3EDFF;
    public static final int MUTED = 0xFF9C8DB8;
    public static final int DIM = 0xFF6B5C88;
    public static final int GOOD = 0xFF7EE787;
    public static final int BAD = 0xFFFF6B8B;

    private Theme() {}

    public static int accent() {
        if (rainbow) {
            float hue = (System.currentTimeMillis() % 6000L) / 6000f;
            return Draw.hsb(hue, 0.55f, 1f);
        }
        if (useCustom) return custom | 0xFF000000;
        return PRESETS[Math.floorMod(preset, PRESETS.length)];
    }

    public static int accentDark() { return Draw.mul(accent(), 0.45f); }

    public static void reset() {
        preset = 0;
        useCustom = false;
        custom = 0xFFA855F7;
        rainbow = false;
        panelOpacity = 0.94f;
        animSpeed = 1.0f;
        cornerRadius = 3;
    }

    public static JsonObject save() {
        JsonObject o = new JsonObject();
        o.addProperty("preset", preset);
        o.addProperty("useCustom", useCustom);
        o.addProperty("custom", String.format("#%08X", custom));
        o.addProperty("rainbow", rainbow);
        o.addProperty("panelOpacity", panelOpacity);
        o.addProperty("animSpeed", animSpeed);
        o.addProperty("cornerRadius", cornerRadius);
        return o;
    }

    public static void load(JsonObject o) {
        reset();
        if (o == null) return;
        try {
            if (o.has("preset")) preset = Math.floorMod(o.get("preset").getAsInt(), PRESETS.length);
            if (o.has("useCustom")) useCustom = o.get("useCustom").getAsBoolean();
            if (o.has("custom")) custom = (int) Long.parseLong(o.get("custom").getAsString().replace("#", ""), 16);
            if (o.has("rainbow")) rainbow = o.get("rainbow").getAsBoolean();
            if (o.has("panelOpacity")) panelOpacity = Math.max(0.5f, Math.min(1f, o.get("panelOpacity").getAsFloat()));
            if (o.has("animSpeed")) animSpeed = Math.max(0.4f, Math.min(2.5f, o.get("animSpeed").getAsFloat()));
            if (o.has("cornerRadius")) cornerRadius = Math.max(0, Math.min(5, o.get("cornerRadius").getAsInt()));
        } catch (RuntimeException ignored) {
            // malformed theme block: fall back to defaults already applied by reset()
        }
    }
}
