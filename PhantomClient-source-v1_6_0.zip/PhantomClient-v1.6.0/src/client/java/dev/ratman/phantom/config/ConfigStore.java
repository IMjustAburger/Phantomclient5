package dev.ratman.phantom.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import dev.ratman.phantom.gui.GuiState;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Friends;
import dev.ratman.phantom.util.Theme;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Multi-profile configuration manager. Every profile is an independent JSON file under
 * {@code config/phantom/profiles/}. Module state, settings, keybinds, ESP colours, block selections,
 * Base Finder settings, theme and GUI layout are all part of the profile. The friends list and the
 * name of the active profile are global ({@code config/phantom/state.json}).
 */
public final class ConfigStore {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int VERSION = 2;
    private static final long SAVE_DELAY_MS = 800L;

    private static Path root;
    private static String active = "default";
    private static boolean dirty;
    private static boolean globalDirty;
    private static long dirtySince;
    private static boolean loading;

    private ConfigStore() {}

    // ------------------------------------------------------------------ paths
    private static Path root() {
        if (root == null) root = FabricLoader.getInstance().getConfigDir().resolve("phantom");
        return root;
    }

    private static Path profilesDir() { return root().resolve("profiles"); }

    private static Path profilePath(String name) { return profilesDir().resolve(name + ".json"); }

    private static Path statePath() { return root().resolve("state.json"); }

    public static String cleanName(String raw) {
        if (raw == null) return "";
        String s = raw.replaceAll("[^A-Za-z0-9 _\\-]", "").trim();
        if (s.length() > 24) s = s.substring(0, 24).trim();
        return s;
    }

    // ------------------------------------------------------------------- init
    public static void init() {
        try {
            Files.createDirectories(profilesDir());
        } catch (IOException e) {
            LOG.error("[Phantom] Could not create config directory", e);
        }
        readGlobal();
        List<String> existing = profiles();
        if (existing.isEmpty()) {
            active = "default";
            applyDefaults();
            writeProfile(active);
        } else {
            if (!existing.contains(active)) active = existing.get(0);
            readProfile(active);
        }
        dirty = false;
        globalDirty = false;
    }

    public static String active() { return active; }

    public static List<String> profiles() {
        List<String> names = new ArrayList<String>();
        try (Stream<Path> files = Files.list(profilesDir())) {
            files.forEach(p -> {
                String n = p.getFileName().toString();
                if (n.endsWith(".json")) names.add(n.substring(0, n.length() - 5));
            });
        } catch (IOException e) {
            // directory missing: no profiles yet
        }
        Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
        return names;
    }

    public static boolean exists(String name) {
        for (String n : profiles()) if (n.equalsIgnoreCase(name)) return true;
        return false;
    }

    // ------------------------------------------------------------ dirty / tick
    public static void markDirty() {
        if (loading) return;
        if (!dirty) dirtySince = System.currentTimeMillis();
        dirty = true;
    }

    public static void markGlobalDirty() {
        if (loading) return;
        if (!globalDirty && !dirty) dirtySince = System.currentTimeMillis();
        globalDirty = true;
    }

    /** Debounced auto-save, called every client tick. */
    public static void tick() {
        if ((dirty || globalDirty) && System.currentTimeMillis() - dirtySince >= SAVE_DELAY_MS) flush();
    }

    public static void flush() {
        if (dirty) {
            writeProfile(active);
            dirty = false;
        }
        if (globalDirty) {
            writeGlobal();
            globalDirty = false;
        }
    }

    // ---------------------------------------------------------- profile actions
    /** Creates a new profile from the current settings and makes it active. */
    public static boolean create(String rawName) {
        String name = cleanName(rawName);
        if (name.isEmpty() || exists(name)) return false;
        flush();
        active = name;
        writeProfile(name);
        writeGlobal();
        return true;
    }

    /** Creates a profile holding factory defaults (does not touch the current profile). */
    public static boolean createDefault(String rawName) {
        String name = cleanName(rawName);
        if (name.isEmpty() || exists(name)) return false;
        flush();
        applyDefaults();
        active = name;
        writeProfile(name);
        writeGlobal();
        return true;
    }

    public static boolean load(String name) {
        if (!exists(name)) return false;
        flush();
        active = realName(name);
        readProfile(active);
        writeGlobal();
        return true;
    }

    public static boolean saveActive() {
        dirty = false;
        return writeProfile(active);
    }

    public static boolean rename(String oldName, String rawNew) {
        String neu = cleanName(rawNew);
        if (neu.isEmpty() || !exists(oldName) || (exists(neu) && !neu.equalsIgnoreCase(oldName))) return false;
        flush();
        String old = realName(oldName);
        try {
            Files.move(profilePath(old), profilePath(neu), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            LOG.error("[Phantom] Could not rename profile", e);
            return false;
        }
        if (active.equalsIgnoreCase(old)) {
            active = neu;
            writeGlobal();
        }
        return true;
    }

    public static boolean delete(String name) {
        if (!exists(name)) return false;
        String real = realName(name);
        List<String> all = profiles();
        if (all.size() <= 1) return false;
        try {
            Files.deleteIfExists(profilePath(real));
        } catch (IOException e) {
            LOG.error("[Phantom] Could not delete profile", e);
            return false;
        }
        if (active.equalsIgnoreCase(real)) {
            List<String> left = profiles();
            active = left.get(0);
            readProfile(active);
            writeGlobal();
        }
        return true;
    }

    public static boolean duplicate(String source, String rawNew) {
        String neu = cleanName(rawNew);
        if (neu.isEmpty() || exists(neu) || !exists(source)) return false;
        flush();
        try {
            Files.copy(profilePath(realName(source)), profilePath(neu));
        } catch (IOException e) {
            LOG.error("[Phantom] Could not duplicate profile", e);
            return false;
        }
        return true;
    }

    /** Resets the live settings to factory defaults and saves them into the active profile. */
    public static void resetActiveToDefaults() {
        applyDefaults();
        dirty = true;
        dirtySince = 0L;
        flush();
    }

    private static String realName(String name) {
        for (String n : profiles()) if (n.equalsIgnoreCase(name)) return n;
        return name;
    }

    // ------------------------------------------------------------- (de)serialise
    private static void applyDefaults() {
        loading = true;
        try {
            for (Module m : ModuleManager.all()) {
                m.resetSettings();
                m.setKeyCode(-1);
                m.applyLoadedState(m.defaultOn);
            }
            Theme.reset();
            GuiState.clear();
        } finally {
            loading = false;
        }
    }

    private static JsonObject snapshot() {
        JsonObject o = new JsonObject();
        o.addProperty("version", VERSION);
        o.addProperty("name", active);
        o.add("theme", Theme.save());
        o.add("gui", GuiState.save());
        JsonObject modules = new JsonObject();
        for (Module m : ModuleManager.all()) {
            JsonObject mo = new JsonObject();
            mo.addProperty("enabled", m.enabled());
            mo.addProperty("key", m.keyCode());
            JsonObject settings = new JsonObject();
            for (Setting<?> s : m.settings()) settings.add(s.key, s.save());
            mo.add("settings", settings);
            modules.add(m.id, mo);
        }
        o.add("modules", modules);
        return o;
    }

    private static boolean writeProfile(String name) {
        try {
            Files.createDirectories(profilesDir());
            writeAtomic(profilePath(name), GSON.toJson(snapshot()));
            return true;
        } catch (IOException | RuntimeException e) {
            LOG.error("[Phantom] Could not save profile {}", name, e);
            return false;
        }
    }

    private static void readProfile(String name) {
        loading = true;
        try {
            applyDefaults();
            loading = true;
            Path path = profilePath(name);
            if (!Files.exists(path)) return;
            try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
                JsonElement parsed = JsonParser.parseReader(reader);
                if (!parsed.isJsonObject()) return;
                JsonObject o = parsed.getAsJsonObject();
                if (o.has("theme") && o.get("theme").isJsonObject()) Theme.load(o.getAsJsonObject("theme"));
                if (o.has("gui") && o.get("gui").isJsonObject()) GuiState.load(o.getAsJsonObject("gui"));
                if (o.has("modules") && o.get("modules").isJsonObject()) {
                    JsonObject modules = o.getAsJsonObject("modules");
                    for (Module m : ModuleManager.all()) {
                        if (!modules.has(m.id) || !modules.get(m.id).isJsonObject()) continue;
                        JsonObject mo = modules.getAsJsonObject(m.id);
                        if (mo.has("key") && mo.get("key").isJsonPrimitive()) m.setKeyCode(mo.get("key").getAsInt());
                        if (mo.has("settings") && mo.get("settings").isJsonObject()) {
                            JsonObject so = mo.getAsJsonObject("settings");
                            for (Setting<?> s : m.settings()) {
                                if (so.has(s.key)) {
                                    try {
                                        s.load(so.get(s.key));
                                    } catch (RuntimeException e) {
                                        LOG.warn("[Phantom] Bad value for {}.{}", m.id, s.key);
                                    }
                                }
                            }
                        }
                        if (mo.has("enabled") && mo.get("enabled").isJsonPrimitive()) {
                            m.applyLoadedState(mo.get("enabled").getAsBoolean());
                        }
                    }
                }
            } catch (IOException | RuntimeException e) {
                LOG.error("[Phantom] Could not read profile {}", name, e);
            }
        } finally {
            loading = false;
        }
    }

    private static void writeGlobal() {
        JsonObject o = new JsonObject();
        o.addProperty("active", active);
        o.add("friends", Friends.save());
        try {
            Files.createDirectories(root());
            writeAtomic(statePath(), GSON.toJson(o));
        } catch (IOException e) {
            LOG.error("[Phantom] Could not save global state", e);
        }
    }

    private static void readGlobal() {
        Path path = statePath();
        if (!Files.exists(path)) return;
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject()) return;
            JsonObject o = parsed.getAsJsonObject();
            if (o.has("active")) active = cleanName(o.get("active").getAsString());
            if (o.has("friends") && o.get("friends").isJsonArray()) Friends.load(o.getAsJsonArray("friends"));
        } catch (IOException | RuntimeException e) {
            LOG.error("[Phantom] Could not read global state", e);
        }
    }

    private static void writeAtomic(Path target, String content) throws IOException {
        Path tmp = target.resolveSibling(target.getFileName().toString() + ".tmp");
        try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
            w.write(content);
        }
        try {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    /** Lower-case id used to build per-world data file names. */
    public static String worldFileId(String key) {
        try {
            java.security.MessageDigest d = java.security.MessageDigest.getInstance("SHA-256");
            byte[] h = d.digest(key.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 12; i++) sb.append(String.format(Locale.ROOT, "%02x", h[i]));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            return Integer.toHexString(key.hashCode());
        }
    }

    public static Path dataDir() {
        Path p = root().resolve("data");
        try {
            Files.createDirectories(p);
        } catch (IOException e) {
            LOG.error("[Phantom] Could not create data directory", e);
        }
        return p;
    }
}
