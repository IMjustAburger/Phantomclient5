package dev.ratman.phantom.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import dev.ratman.phantom.config.ConfigStore;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

/** Global friends list (shared by every profile). Friends are never targeted by combat modules. */
public final class Friends {
    private static final Set<String> NAMES = new TreeSet<String>();

    private Friends() {}

    public static boolean is(String name) {
        return name != null && NAMES.contains(name.toLowerCase(Locale.ROOT));
    }

    public static boolean add(String name) {
        if (name == null) return false;
        String n = name.trim();
        if (n.isEmpty() || n.length() > 16 || !n.matches("[A-Za-z0-9_.]+")) return false;
        boolean added = NAMES.add(n.toLowerCase(Locale.ROOT));
        if (added) ConfigStore.markGlobalDirty();
        return added;
    }

    public static boolean remove(String name) {
        boolean removed = NAMES.remove(name.toLowerCase(Locale.ROOT));
        if (removed) ConfigStore.markGlobalDirty();
        return removed;
    }

    public static List<String> list() { return new ArrayList<String>(NAMES); }

    public static JsonArray save() {
        JsonArray a = new JsonArray();
        for (String s : NAMES) a.add(s);
        return a;
    }

    public static void load(JsonArray a) {
        NAMES.clear();
        if (a == null) return;
        for (JsonElement e : a) {
            try {
                NAMES.add(e.getAsString().toLowerCase(Locale.ROOT));
            } catch (RuntimeException ignored) {
                // skip malformed entry
            }
        }
    }
}
