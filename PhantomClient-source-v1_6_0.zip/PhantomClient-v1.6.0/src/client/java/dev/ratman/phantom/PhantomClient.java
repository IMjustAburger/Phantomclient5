package dev.ratman.phantom;

import dev.ratman.phantom.config.ConfigStore;
import dev.ratman.phantom.gui.ClickGui;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.modules.BaseModules;
import dev.ratman.phantom.modules.VisualModules;
import dev.ratman.phantom.util.Compat;
import dev.ratman.phantom.world.SpawnerTracker;
import dev.ratman.phantom.world.SuspiciousChunkFinder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class PhantomClient implements ClientModInitializer {
    public static final String MOD_ID = "phantom";
    private static KeyBinding openGuiKey;
    private static long lastFrameNanos = System.nanoTime();

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.phantom.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        // Modules must exist before the profile is loaded into them.
        ModuleManager.init();
        ConfigStore.init();

        ClientTickEvents.START_CLIENT_TICK.register(ModuleManager::preTick);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen instanceof ClickGui) {
                    client.setScreen(null);
                } else if (client.currentScreen == null) {
                    client.setScreen(new ClickGui());
                }
            }
            ModuleManager.tick(client);
        });

        // Custom crosshair replaces the vanilla one only while that module asks for it.
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (context, tickCounter) -> {
            if (!VisualModules.hideVanillaCrosshair()) original.render(context, tickCounter);
        });

        HudElementRegistry.addLast(Identifier.of(MOD_ID, "phantom_hud"), (context, tickCounter) -> {
            long now = System.nanoTime();
            float dt = Math.max(0.0005f, Math.min(0.1f, (now - lastFrameNanos) / 1.0e9f));
            lastFrameNanos = now;
            ModuleManager.frame(dt);
            ModuleManager.renderHud(context, Compat.tickDelta());
        });

        WorldRenderEvents.AFTER_ENTITIES.register(ModuleManager::renderWorld);

        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> {
            if (world == MinecraftClient.getInstance().world) {
                BaseModules.chunkLoaded(chunk.getPos().x, chunk.getPos().z);
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ConfigStore.flush();
            SuspiciousChunkFinder.save();
            SpawnerTracker.save();
        });
    }
}
