package dev.ratman.phantom.modules;

import com.mojang.authlib.GameProfile;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Blocks;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Friends;
import dev.ratman.phantom.util.Notifier;
import dev.ratman.phantom.util.RenderUtil;
import dev.ratman.phantom.util.Targets;
import dev.ratman.phantom.world.BlockScanner;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Render category: ESPs, tracers, trajectories and view helpers. Everything draws through walls. */
public final class RenderModules {
    private RenderModules() {}

    public static void register() {
        ModuleManager.register(new EntityEsp());
        ModuleManager.register(new StorageEsp());
        ModuleManager.register(new BlockEsp());
        ModuleManager.register(new Fullbright());
        ModuleManager.register(new Freecam());
        ModuleManager.register(new HoleEsp());
        ModuleManager.register(new ItemEsp());
        ModuleManager.register(new LowHealthWarning());
        ModuleManager.register(new PearlTrajectory());
        ModuleManager.register(new TracersModule());
        ModuleManager.register(new Trajectories());
    }

    // ================================================================== Entity ESP
    static final class EntityEsp extends Module {
        final Setting.Bool players = bool("players", "Players", true);
        final Setting.Bool mobs = bool("mobs", "Mobs", true);
        final Setting.Bool passive = bool("passive", "Passive mobs", true);
        final Setting.Col playerColor = color("playercolor", "Player colour", 0xFFC084FC);
        final Setting.Col mobColor = color("mobcolor", "Mob colour", 0xFFFF6B8B);
        final Setting.Col friendColor = color("friendcolor", "Friend colour", 0xFF7EE787);
        final Setting.Num range = num("range", "Range", 64.0, 8.0, 256.0, 4.0, " blocks");
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Col glowColor = color("glowcolor", "Glow colour", 0xFFE9D5FF);
        final Setting.Num glowIntensity = num("glowintensity", "Glow intensity", 2.0, 1.0, 5.0, 1.0);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        final Setting.Bool modelOutline = bool("model", "Vanilla model outline", false);
        private final Map<Entity, Boolean> changed = new IdentityHashMap<Entity, Boolean>();

        EntityEsp() {
            super("entity_esp", "Entity ESP", ModuleCategory.RENDER,
                    "Outlines players and mobs through walls with custom colours, glow and tracers.");
            glowColor.visibleWhen(() -> glow.on());
            glowIntensity.visibleWhen(() -> glow.on());
        }

        private boolean accept(LivingEntity e) {
            if (e == mc.player || !e.isAlive() || e instanceof ArmorStandEntity || e.isSpectator()) return false;
            if (e instanceof PlayerEntity) return players.on();
            if (!mobs.on()) return false;
            return passive.on() || e instanceof Monster;
        }

        private int colorOf(LivingEntity e) {
            if (e instanceof PlayerEntity) return Friends.is(e.getName().getString()) ? friendColor.argb() : playerColor.argb();
            return mobColor.argb();
        }

        @Override public void onTick() {
            if (!modelOutline.on()) {
                restore();
                return;
            }
            Set<Entity> wanted = new HashSet<Entity>();
            double r2 = range.d() * range.d();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity) || mc.player.squaredDistanceTo(e) > r2 || !accept((LivingEntity) e)) continue;
                wanted.add(e);
                if (!changed.containsKey(e)) changed.put(e, e.isGlowing());
                if (!e.isGlowing()) e.setGlowing(true); // re-applied each tick: server flag updates would clear it
            }
            Iterator<Map.Entry<Entity, Boolean>> it = changed.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Entity, Boolean> en = it.next();
                if (!wanted.contains(en.getKey())) {
                    en.getKey().setGlowing(en.getValue());
                    it.remove();
                }
            }
        }

        private void restore() {
            for (Map.Entry<Entity, Boolean> en : changed.entrySet()) en.getKey().setGlowing(en.getValue());
            changed.clear();
        }

        @Override public void onDisable() { restore(); }

        @Override public void onWorldReset() { changed.clear(); }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof LivingEntity)) continue;
                LivingEntity le = (LivingEntity) e;
                if (mc.player.squaredDistanceTo(e) > r2 || !accept(le)) continue;
                Box box = RenderUtil.lerpedBox(e, td);
                int c = colorOf(le);
                pass.box(box, c, 0, 0f);
                if (glow.on()) pass.glow(box, glowColor.argb(), glowIntensity.i() + 1, 1.0f);
                if (tracers.on()) pass.tracer(box.getCenter(), c);
            }
        }
    }

    // ================================================================== Storage ESP
    static final class StorageEsp extends Module {
        final Setting.Col defaultColor = color("default", "Default colour", 0xFFFFD76B);
        final Setting.Bool typeColors = bool("typecolors", "Colour by storage type", true);
        final Setting.Blocks blocks = add(new Setting.Blocks("blocks", "Storage blocks / colours", 0xFFFFD76B,
                Blocks.storageIds(), true));
        final Setting.Num range = num("range", "Range", 96.0, 16.0, 256.0, 4.0, " blocks");
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Col glowColor = color("glowcolor", "Glow colour", 0xFFFFE9A8);
        final Setting.Num glowIntensity = num("glowintensity", "Glow intensity", 2.0, 1.0, 5.0, 1.0);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);

        private static final class Entry {
            BlockPos pos;
            String id;
            List<Box> boxes;
        }

        private final List<Entry> cache = new ArrayList<Entry>();
        private int refresh;

        StorageEsp() {
            super("storage_esp", "Storage ESP", ModuleCategory.RENDER,
                    "Outlines chests, barrels, shulkers and other storage through walls.");
            glowColor.visibleWhen(() -> glow.on());
            glowIntensity.visibleWhen(() -> glow.on());
            defaultColor.visibleWhen(() -> !typeColors.on());
        }

        static int palette(String id) {
            if (id.contains("shulker_box")) return 0xFFD58CFF;
            if (id.contains("barrel")) return 0xFFFFB86B;
            if (id.contains("ender_chest")) return 0xFF6BE7D8;
            if (id.contains("hopper")) return 0xFFB5C1D8;
            if (id.contains("furnace") || id.contains("smoker") || id.contains("brewing_stand")) return 0xFFFF8B75;
            if (id.contains("dispenser") || id.contains("dropper")) return 0xFFA3A3A3;
            return 0xFFFFD76B;
        }

        private int colorFor(String id) {
            if (blocks.contains(id)) return blocks.colorOf(id);
            return typeColors.on() ? palette(id) : defaultColor.argb();
        }

        @Override public void onWorldReset() { cache.clear(); }

        @Override public void onDisable() { cache.clear(); }

        @Override public void onTick() {
            if (refresh-- > 0) return;
            refresh = 20;
            cache.clear();
            int radius = (int) Math.ceil(range.d() / 16.0) + 1;
            int pcx = mc.player.getBlockX() >> 4;
            int pcz = mc.player.getBlockZ() >> 4;
            for (int cx = pcx - radius; cx <= pcx + radius; cx++) {
                for (int cz = pcz - radius; cz <= pcz + radius; cz++) {
                    Chunk chunk = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (chunk == null) continue;
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        BlockState state = be.getCachedState();
                        String id = BlockScanner.idOf(state);
                        if (!Blocks.isStorageId(id) || !blocks.accepts(id)) continue;
                        Entry en = new Entry();
                        en.pos = be.getPos().toImmutable();
                        en.id = id;
                        en.boxes = new ArrayList<Box>();
                        try {
                            VoxelShape shape = state.getOutlineShape(mc.world, en.pos, ShapeContext.absent());
                            for (Box b : shape.getBoundingBoxes()) {
                                en.boxes.add(b.offset(en.pos.getX(), en.pos.getY(), en.pos.getZ()));
                                if (en.boxes.size() >= 8) break;
                            }
                        } catch (RuntimeException ignored) {
                            // use a full block below
                        }
                        if (en.boxes.isEmpty()) en.boxes.add(new Box(en.pos));
                        cache.add(en);
                    }
                }
            }
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (cache.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            for (Entry en : cache) {
                Vec3d center = Vec3d.ofCenter(en.pos);
                if (center.squaredDistanceTo(pass.camera) > r2) continue;
                int c = colorFor(en.id);
                for (Box b : en.boxes) {
                    pass.box(b, c, 0, 0f);
                    if (glow.on()) pass.glow(b, glowColor.argb(), glowIntensity.i() + 1, 1.0f);
                }
                if (tracers.on()) pass.tracer(center, c);
            }
        }
    }

    // ================================================================== Block ESP
    static final class BlockEsp extends Module {
        final Setting.Blocks blocks = add(new Setting.Blocks("blocks", "Blocks", 0xFF7DD3FC, null, false));
        final Setting.Num radius = num("radius", "Scan radius", 4.0, 1.0, 10.0, 1.0, " chunks");
        final Setting.Num range = num("range", "Render range", 96.0, 16.0, 256.0, 4.0, " blocks");
        final Setting.Num minY = num("miny", "Min Y", -64.0, -64.0, 320.0, 1.0);
        final Setting.Num maxY = num("maxy", "Max Y", 320.0, -64.0, 320.0, 1.0);
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Col glowColor = color("glowcolor", "Glow colour", 0xFFBAE6FD);
        final Setting.Num glowIntensity = num("glowintensity", "Glow intensity", 2.0, 1.0, 5.0, 1.0);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);
        final Setting.Num maxTracers = num("maxtracers", "Max tracers", 20.0, 1.0, 100.0, 1.0);
        final Setting.Num maxBoxes = num("maxboxes", "Max highlighted", 600.0, 50.0, 3000.0, 50.0);
        private final BlockScanner scanner = new BlockScanner();
        private int lastSelectionHash;

        BlockEsp() {
            super("block_esp", "Block ESP", ModuleCategory.RENDER,
                    "Search and select any blocks, then see them through walls with per-block colours.");
            glowColor.visibleWhen(() -> glow.on());
            glowIntensity.visibleWhen(() -> glow.on());
            maxTracers.visibleWhen(() -> tracers.on());
        }

        @Override public void onEnable() { scanner.invalidate(); }

        @Override public void onWorldReset() { scanner.invalidate(); }

        @Override public void onTick() {
            if (blocks.map().isEmpty()) return;
            int hash = blocks.map().keySet().hashCode();
            if (hash != lastSelectionHash) {
                lastSelectionHash = hash;
                scanner.invalidate();
            }
            scanner.tick(mc, id -> blocks.contains(id), radius.i(), ClientModules.scansPerTick(), ClientModules.rescanMs(), minY.i(), maxY.i());
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (blocks.map().isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            List<BlockScanner.Hit> near = new ArrayList<BlockScanner.Hit>();
            for (BlockScanner.Hit h : scanner.hits()) {
                if (Vec3d.ofCenter(h.pos).squaredDistanceTo(pass.camera) <= r2) near.add(h);
            }
            near.sort((a, b) -> Double.compare(Vec3d.ofCenter(a.pos).squaredDistanceTo(pass.camera),
                    Vec3d.ofCenter(b.pos).squaredDistanceTo(pass.camera)));
            int drawn = 0;
            int tracerCount = 0;
            for (BlockScanner.Hit h : near) {
                if (drawn++ >= maxBoxes.i()) break;
                int c = blocks.colorOf(h.id);
                Box b = new Box(h.pos);
                pass.box(b, c, 0, 0f);
                if (glow.on()) pass.glow(b, glowColor.argb(), glowIntensity.i() + 1, 1.0f);
                if (tracers.on() && tracerCount < maxTracers.i()) {
                    pass.tracer(Vec3d.ofCenter(h.pos), c);
                    tracerCount++;
                }
            }
        }
    }

    // ================================================================== Fullbright
    static final class Fullbright extends Module {
        final Setting.Mode mode = mode("mode", "Mode", "Night Vision", "Night Vision", "Gamma");
        private boolean applied;
        private double previousGamma = 0.5;
        private boolean gammaChanged;

        Fullbright() {
            super("fullbright", "Fullbright", ModuleCategory.RENDER, "See clearly in the dark.");
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (mode.is("Night Vision")) {
                restoreGamma();
                if (!p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, false, false, false));
                    applied = true;
                }
            } else {
                removeEffect();
                if (!gammaChanged) {
                    previousGamma = mc.options.getGamma().getValue();
                    gammaChanged = true;
                }
                mc.options.getGamma().setValue(1.0);
            }
        }

        private void removeEffect() {
            if (applied && mc.player != null) {
                StatusEffectInstance inst = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
                if (inst != null && inst.getDuration() > 500_000) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            }
            applied = false;
        }

        private void restoreGamma() {
            if (gammaChanged) mc.options.getGamma().setValue(previousGamma);
            gammaChanged = false;
        }

        @Override public void onDisable() {
            removeEffect();
            restoreGamma();
        }

        @Override public String info() { return mode.get(); }
    }

    // ================================================================== Freecam
    static final class Freecam extends Module {
        final Setting.Num speed = num("speed", "Speed", 1.0, 0.1, 5.0, 0.1, "x");
        private OtherClientPlayerEntity cam;
        private Vec3d pos = Vec3d.ZERO;

        Freecam() {
            super("freecam", "Freecam", ModuleCategory.RENDER,
                    "Detaches the camera so you can fly around while your character stays put. (Look direction is shared.)");
        }

        private boolean down(KeyBinding key) {
            int code = KeyBindingHelper.getBoundKeyOf(key).getCode();
            return code >= 0 && GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == GLFW.GLFW_PRESS;
        }

        @Override public void onEnable() {
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null) {
                mc.execute(() -> setEnabled(false));
                return;
            }
            GameProfile profile = p.getGameProfile();
            cam = new OtherClientPlayerEntity(mc.world, profile);
            pos = p.getEyePos();
            cam.setPosition(pos.x, pos.y - 1.62, pos.z);
            cam.setYaw(p.getYaw());
            cam.setPitch(p.getPitch());
            mc.setCameraEntity(cam);
        }

        @Override public void onPreTick() {
            // Freeze the real player: its movement input is cleared before the tick processes it.
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(false);
            mc.options.leftKey.setPressed(false);
            mc.options.rightKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sneakKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
        }

        @Override public void onTick() {
            ClientPlayerEntity p = mc.player;
            if (cam == null) return;
            if (mc.currentScreen == null) {
                double f = (down(mc.options.forwardKey) ? 1 : 0) - (down(mc.options.backKey) ? 1 : 0);
                double s = (down(mc.options.leftKey) ? 1 : 0) - (down(mc.options.rightKey) ? 1 : 0);
                double y = (down(mc.options.jumpKey) ? 1 : 0) - (down(mc.options.sneakKey) ? 1 : 0);
                Vec3d dir = MovementModules.direction(f, s, p.getYaw());
                double v = 0.6 * speed.d();
                pos = pos.add(dir.x * v, y * v, dir.z * v);
            }
            cam.setPosition(pos.x, pos.y - 1.62, pos.z);
            cam.setYaw(p.getYaw());
            cam.setPitch(p.getPitch());
            if (mc.getCameraEntity() != cam) mc.setCameraEntity(cam);
        }

        @Override public void onDisable() {
            if (mc.player != null) mc.setCameraEntity(mc.player);
            cam = null;
            KeyBinding.updatePressedStates();
        }

        @Override public void onWorldReset() {
            cam = null;
            if (isOn()) setEnabled(false);
        }

        private boolean isOn() { return enabled(); }
    }

    // ================================================================== Hole ESP
    static final class HoleEsp extends Module {
        final Setting.Num radius = num("radius", "Radius", 6.0, 2.0, 12.0, 1.0, " blocks");
        final Setting.Col safeColor = color("safecolor", "Bedrock hole", 0xFF7EE787);
        final Setting.Col mixedColor = color("mixedcolor", "Mixed hole", 0xFFFFD166);
        final Setting.Col unsafeColor = color("unsafecolor", "Obsidian hole", 0xFFFF6B8B);
        final Setting.Bool glow = bool("glow", "Glow", false);
        final Setting.Col glowColor = color("glowcolor", "Glow colour", 0xFFFFFFFF);
        private final List<BlockPos> holes = new ArrayList<BlockPos>();
        private final List<Integer> colors = new ArrayList<Integer>();
        private int refresh;

        HoleEsp() {
            super("hole_esp", "Hole ESP", ModuleCategory.RENDER,
                    "Highlights safe 1x1 holes (bedrock / obsidian walls) around you.");
            glowColor.visibleWhen(() -> glow.on());
        }

        private static boolean solidWall(BlockState s) {
            return s.isOf(net.minecraft.block.Blocks.BEDROCK) || s.isOf(net.minecraft.block.Blocks.OBSIDIAN)
                    || s.isOf(net.minecraft.block.Blocks.CRYING_OBSIDIAN) || s.isOf(net.minecraft.block.Blocks.NETHERITE_BLOCK)
                    || s.isOf(net.minecraft.block.Blocks.RESPAWN_ANCHOR) || s.isOf(net.minecraft.block.Blocks.ENDER_CHEST);
        }

        @Override public void onWorldReset() {
            holes.clear();
            colors.clear();
        }

        @Override public void onTick() {
            if (refresh-- > 0) return;
            refresh = 10;
            holes.clear();
            colors.clear();
            BlockPos origin = mc.player.getBlockPos();
            int r = radius.i();
            BlockPos.Mutable m = new BlockPos.Mutable();
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r / 2 - 1; dy <= r / 2; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        BlockPos pos = origin.add(dx, dy, dz);
                        if (!mc.world.getBlockState(pos).isAir() || !mc.world.getBlockState(pos.up()).isAir()
                                || !mc.world.getBlockState(pos.up(2)).isAir()) continue;
                        BlockState floor = mc.world.getBlockState(pos.down());
                        if (!solidWall(floor)) continue;
                        BlockState[] walls = {
                                mc.world.getBlockState(pos.north()), mc.world.getBlockState(pos.south()),
                                mc.world.getBlockState(pos.east()), mc.world.getBlockState(pos.west())};
                        boolean ok = true;
                        int bedrock = floor.isOf(net.minecraft.block.Blocks.BEDROCK) ? 1 : 0;
                        int total = 1;
                        for (BlockState w : walls) {
                            if (!solidWall(w)) {
                                ok = false;
                                break;
                            }
                            total++;
                            if (w.isOf(net.minecraft.block.Blocks.BEDROCK)) bedrock++;
                        }
                        if (!ok) continue;
                        holes.add(pos);
                        colors.add(bedrock == total ? safeColor.argb() : (bedrock == 0 ? unsafeColor.argb() : mixedColor.argb()));
                    }
                }
            }
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            if (holes.isEmpty()) return;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            for (int i = 0; i < holes.size(); i++) {
                BlockPos p = holes.get(i);
                Box flat = new Box(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 0.05, p.getZ() + 1);
                pass.box(flat, colors.get(i), 0, 0f);
                if (glow.on()) pass.glow(flat, glowColor.argb(), 2, 1.0f);
            }
        }
    }

    // ================================================================== Item ESP
    static final class ItemEsp extends Module {
        final Setting.Col color = color("color", "Colour", 0xFF93C5FD);
        final Setting.Num range = num("range", "Range", 48.0, 8.0, 256.0, 4.0, " blocks");
        final Setting.Bool glow = bool("glow", "Glow", true);
        final Setting.Col glowColor = color("glowcolor", "Glow colour", 0xFFDBEAFE);
        final Setting.Bool tracers = bool("tracers", "Tracers", false);

        ItemEsp() {
            super("item_esp", "Item ESP", ModuleCategory.RENDER, "Outlines dropped items through walls.");
            glowColor.visibleWhen(() -> glow.on());
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof ItemEntity) || mc.player.squaredDistanceTo(e) > r2) continue;
                Box b = RenderUtil.lerpedBox(e, td);
                pass.box(b, color.argb(), 0, 0f);
                if (glow.on()) pass.glow(b, glowColor.argb(), 2, 1.0f);
                if (tracers.on()) pass.tracer(b.getCenter(), color.argb());
            }
        }
    }

    // ================================================================== Low Health Warning
    static final class LowHealthWarning extends Module {
        final Setting.Num threshold = num("threshold", "Warn at or below", 6.0, 1.0, 19.0, 0.5, " HP");
        final Setting.Bool vignette = bool("vignette", "Red screen edges", true);
        final Setting.Bool sound = bool("sound", "Warning sound", true);
        final Setting.Bool chat = bool("chat", "Chat message", false);
        private boolean low;
        private int soundTimer;

        LowHealthWarning() {
            super("low_health_warning", "Low Health Warning", ModuleCategory.RENDER,
                    "Pulses the screen edges red and plays a warning when your health is low.");
        }

        @Override public void onTick() {
            float hp = mc.player.getHealth() + mc.player.getAbsorptionAmount();
            boolean now = hp <= threshold.d() && hp > 0;
            if (now && !low && chat.on()) Notifier.chat("Low health: " + String.format(java.util.Locale.ROOT, "%.1f", hp) + " HP");
            low = now;
            if (low && sound.on()) {
                if (soundTimer-- <= 0) {
                    Notifier.sound(Notifier.SOUND_WARN, 0.5f, 1.6f);
                    soundTimer = 40;
                }
            } else {
                soundTimer = 0;
            }
        }

        @Override public void onHud(DrawContext ctx, float td) {
            if (!low || !vignette.on()) return;
            int w = ctx.getScaledWindowWidth();
            int h = ctx.getScaledWindowHeight();
            double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 220.0);
            int strong = Draw.setAlpha(0xFFFF2040, (int) (90 + 80 * pulse));
            int none = 0x00FF2040;
            int band = Math.max(20, h / 6);
            ctx.fillGradient(0, 0, w, band, strong, none);
            ctx.fillGradient(0, h - band, w, h, none, strong);
        }
    }

    // ================================================================== Pearl Trajectory
    static List<Vec3d> simulate(Vec3d start, Vec3d velocity, double gravity, double drag, int maxSteps, Entity self) {
        List<Vec3d> points = new ArrayList<Vec3d>();
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        Vec3d pos = start;
        Vec3d vel = velocity;
        points.add(pos);
        for (int i = 0; i < maxSteps; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, self));
            if (hit.getType() != HitResult.Type.MISS) {
                points.add(hit.getPos());
                break;
            }
            pos = next;
            points.add(pos);
            vel = vel.multiply(drag).subtract(0, gravity, 0);
            if (pos.y < mc.world.getBottomY() - 8) break;
        }
        return points;
    }

    static void drawPath(RenderUtil.Pass pass, List<Vec3d> path, int color, boolean landing) {
        pass.strip(path, color);
        if (landing && !path.isEmpty()) {
            Vec3d end = path.get(path.size() - 1);
            pass.box(new Box(end.x - 0.25, end.y - 0.05, end.z - 0.25, end.x + 0.25, end.y + 0.05, end.z + 0.25), color, 0, 0f);
        }
    }

    static final class PearlTrajectory extends Module {
        final Setting.Col color = color("color", "Colour", 0xFF6BE7D8);
        final Setting.Num range = num("range", "Range", 128.0, 16.0, 256.0, 8.0, " blocks");
        final Setting.Bool ownOnly = bool("own", "Only my pearls", false);

        PearlTrajectory() {
            super("pearl_trajectory", "Pearl Trajectory", ModuleCategory.RENDER,
                    "Draws the predicted flight path and landing point of ender pearls in the air.");
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            for (Entity e : mc.world.getEntities()) {
                if (!(e instanceof EnderPearlEntity) || mc.player.squaredDistanceTo(e) > r2) continue;
                if (ownOnly.on() && ((EnderPearlEntity) e).getOwner() != mc.player) continue;
                drawPath(pass, simulate(dev.ratman.phantom.util.Compat.pos(e), e.getVelocity(), 0.03, 0.99, 200, e), color.argb(), true);
            }
        }
    }

    // ================================================================== Tracers
    static final class TracersModule extends Module {
        final Setting.Bool players = bool("players", "Players", true);
        final Setting.Bool mobs = bool("mobs", "Hostile mobs", false);
        final Setting.Bool items = bool("items", "Dropped items", false);
        final Setting.Col playerColor = color("playercolor", "Player colour", 0xFFC084FC);
        final Setting.Col mobColor = color("mobcolor", "Mob colour", 0xFFFF6B8B);
        final Setting.Col itemColor = color("itemcolor", "Item colour", 0xFF93C5FD);
        final Setting.Col friendColor = color("friendcolor", "Friend colour", 0xFF7EE787);
        final Setting.Num range = num("range", "Range", 128.0, 8.0, 300.0, 4.0, " blocks");

        TracersModule() {
            super("tracers", "Tracers", ModuleCategory.RENDER, "Draws lines from your crosshair to entities through walls.");
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            double r2 = range.d() * range.d();
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || mc.player.squaredDistanceTo(e) > r2) continue;
                int c;
                if (e instanceof PlayerEntity && players.on()) {
                    c = Friends.is(e.getName().getString()) ? friendColor.argb() : playerColor.argb();
                } else if (e instanceof Monster && mobs.on()) {
                    c = mobColor.argb();
                } else if (e instanceof ItemEntity && items.on()) {
                    c = itemColor.argb();
                } else {
                    continue;
                }
                pass.tracer(RenderUtil.lerpedBox(e, td).getCenter(), c);
            }
        }
    }

    // ================================================================== Trajectories
    static final class Trajectories extends Module {
        final Setting.Col color = color("color", "Colour", 0xFFFFD166);
        final Setting.Bool throwables = bool("throwables", "Show for throwables", true);

        Trajectories() {
            super("trajectories", "Trajectories", ModuleCategory.RENDER,
                    "Predicts where the item you are drawing or holding will land.");
        }

        @Override public void onRender3D(WorldRenderContext ctx, float td) {
            ClientPlayerEntity p = mc.player;
            RenderUtil.Pass pass = RenderUtil.begin(ctx);
            if (pass == null) return;
            ItemStack stack = p.getMainHandStack();
            double speed;
            double gravity;
            if (stack.getItem() instanceof BowItem) {
                if (!p.isUsingItem()) return;
                float pull = BowItem.getPullProgress(p.getItemUseTime());
                if (pull < 0.1f) return;
                speed = pull * 3.0;
                gravity = 0.05;
            } else if (stack.getItem() instanceof CrossbowItem) {
                if (!CrossbowItem.isCharged(stack)) return;
                speed = 3.15;
                gravity = 0.05;
            } else if (stack.isOf(Items.TRIDENT)) {
                if (!p.isUsingItem()) return;
                speed = 2.5;
                gravity = 0.05;
            } else if (throwables.on() && (stack.isOf(Items.ENDER_PEARL) || stack.isOf(Items.SNOWBALL) || stack.isOf(Items.EGG))) {
                speed = 1.5;
                gravity = 0.03;
            } else if (throwables.on() && (stack.isOf(Items.SPLASH_POTION) || stack.isOf(Items.LINGERING_POTION))) {
                speed = 0.5;
                gravity = 0.05;
            } else if (throwables.on() && stack.isOf(Items.EXPERIENCE_BOTTLE)) {
                speed = 0.7;
                gravity = 0.07;
            } else {
                return;
            }
            Vec3d look = p.getRotationVec(td);
            Vec3d start = p.getEyePos().subtract(0, 0.1, 0);
            drawPath(pass, simulate(start, look.multiply(speed), gravity, 0.99, 160, p), color.argb(), true);
        }
    }
}
