package dev.ratman.phantom.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

import java.util.function.Predicate;

/**
 * Inventory helpers. "Index" means PlayerInventory index (0-8 hotbar, 9-35 main). Slot ids refer to
 * the player screen handler (hotbar 36-44, main 9-35, armor 5-8, offhand 45).
 */
public final class Inv {
    public static final int OFFHAND_SLOT_ID = 45;

    private Inv() {}

    public static int slotId(int inventoryIndex) {
        return inventoryIndex < 9 ? 36 + inventoryIndex : inventoryIndex;
    }

    /** True when it is safe to send slot clicks for the player's own inventory. */
    public static boolean canClick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        return p != null && mc.interactionManager != null && p.currentScreenHandler == p.playerScreenHandler;
    }

    public static int findHotbar(Predicate<ItemStack> test) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return -1;
        for (int i = 0; i < 9; i++) {
            if (test.test(mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    /** Searches hotbar and main inventory. */
    public static int find(Predicate<ItemStack> test) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return -1;
        for (int i = 0; i < 36; i++) {
            if (test.test(mc.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }

    public static void click(int slotId, int button, SlotActionType type) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!canClick()) return;
        mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotId, button, type, mc.player);
    }

    public static void swapToOffhand(int inventoryIndex) {
        click(slotId(inventoryIndex), 40, SlotActionType.SWAP);
    }

    /** Swaps an inventory index into a hotbar slot. */
    public static void swapToHotbar(int inventoryIndex, int hotbarSlot) {
        click(slotId(inventoryIndex), hotbarSlot, SlotActionType.SWAP);
    }

    public static ItemStack main() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player == null ? ItemStack.EMPTY : mc.player.getMainHandStack();
    }

    public static ItemStack offhand() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player == null ? ItemStack.EMPTY : mc.player.getOffHandStack();
    }
}
