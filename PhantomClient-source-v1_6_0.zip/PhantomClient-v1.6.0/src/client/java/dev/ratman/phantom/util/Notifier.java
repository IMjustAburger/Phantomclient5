package dev.ratman.phantom.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Chat + sound notifications. Sound ids are distinct per feature so alerts are recognisable. */
public final class Notifier {
    /** Suspicious chunk found. */
    public static final String SOUND_SUSPICIOUS = "entity.player.levelup";
    /** Spawner found: deliberately very different from the suspicious-chunk chime. */
    public static final String SOUND_SPAWNER = "entity.wither.spawn";
    public static final String SOUND_PING = "entity.experience_orb.pickup";
    public static final String SOUND_WARN = "block.anvil.land";

    private Notifier() {}

    public static void chat(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        MutableText prefix = Text.literal("[Phantom] ").formatted(Formatting.LIGHT_PURPLE, Formatting.BOLD);
        MutableText body = Text.literal(message).formatted(Formatting.WHITE);
        mc.player.sendMessage(prefix.append(body), false);
    }

    public static void sound(String id, float volume, float pitch) {
        try {
            Compat.playSound(id, volume, pitch);
        } catch (RuntimeException ignored) {
            // audio must never break gameplay
        }
    }
}
