package dev.ratman.phantom.util;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.PhantomRenderLayerFactory;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/**
 * World-space line drawing that ignores depth, so everything drawn through here is visible through
 * walls. All coordinates handed to the drawing methods are WORLD coordinates; the camera offset is
 * applied internally.
 */
public final class RenderUtil {
    private static final RenderLayer XRAY_LINES = createXrayLayer();

    private RenderUtil() {}

    private static RenderLayer createXrayLayer() {
        RenderPipeline base = RenderPipelines.LINES;
        RenderPipeline.Snippet lineSnippet = new RenderPipeline.Snippet(
                Optional.of(base.getVertexShader()),
                Optional.of(base.getFragmentShader()),
                Optional.of(base.getShaderDefines()),
                Optional.of(base.getSamplers()),
                Optional.of(base.getUniforms()),
                base.getBlendFunction(),
                Optional.of(DepthTestFunction.NO_DEPTH_TEST),
                Optional.of(base.getPolygonMode()),
                Optional.of(base.isCull()),
                Optional.of(base.isWriteColor()),
                Optional.of(base.isWriteAlpha()),
                Optional.of(false),
                Optional.of(base.getColorLogic()),
                Optional.of(base.getVertexFormat()),
                Optional.of(base.getVertexFormatMode())
        );
        RenderPipeline pipeline = RenderPipelines.register(RenderPipeline.builder(lineSnippet)
                .withLocation(Identifier.of("phantom", "pipeline/xray_lines"))
                .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                .withDepthWrite(false)
                .build());
        return PhantomRenderLayerFactory.create("phantom_xray_lines", pipeline);
    }

    /** Per-frame drawing session bound to one world render callback. */
    public static final class Pass {
        private final VertexConsumer consumer;
        private final MatrixStack matrices;
        public final Vec3d camera;
        public final Vec3d look;

        private Pass(VertexConsumer consumer, MatrixStack matrices, Vec3d camera, Vec3d look) {
            this.consumer = consumer;
            this.matrices = matrices;
            this.camera = camera;
            this.look = look;
        }

        /** Axis-aligned box outline. {@code glowPasses} > 0 adds soft fading outlines around it. */
        public void box(Box b, int argb, int glowPasses, float glowStrength) {
            drawBox(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, argb, 0.002);
            for (int i = 1; i <= glowPasses; i++) {
                float fade = glowStrength * (1f - (i - 1f) / (glowPasses + 0.5f)) * 0.55f;
                int c = Draw.alpha(argb, Math.max(0.04f, Math.min(1f, fade)));
                drawBox(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ, c, 0.002 + i * 0.018);
            }
        }

        /** Soft glow halo drawn as fading, progressively larger outlines. */
        public void glow(Box b, int glowArgb, int passes, float strength) {
            for (int i = 1; i <= passes; i++) {
                float fade = strength * (1f - (i - 1f) / (passes + 0.5f)) * 0.55f;
                drawBox(b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ,
                        Draw.alpha(glowArgb, Math.max(0.04f, Math.min(1f, fade))), 0.002 + i * 0.018);
            }
        }

        /** Connected line strip through the given world points. */
        public void strip(java.util.List<Vec3d> points, int argb) {
            for (int i = 1; i < points.size(); i++) line(points.get(i - 1), points.get(i), argb);
        }

        public void box(double x1, double y1, double z1, double x2, double y2, double z2, int argb, int glowPasses, float glowStrength) {
            box(new Box(x1, y1, z1, x2, y2, z2), argb, glowPasses, glowStrength);
        }

        /** Line between two world points. */
        public void line(Vec3d a, Vec3d b, int argb) {
            lineRel((float) (a.x - camera.x), (float) (a.y - camera.y), (float) (a.z - camera.z),
                    (float) (b.x - camera.x), (float) (b.y - camera.y), (float) (b.z - camera.z), argb);
        }

        /** Line from just in front of the camera (crosshair) to a world point. */
        public void tracer(Vec3d target, int argb) {
            Vec3d start = camera.add(look.multiply(0.6));
            line(start, target, argb);
        }

        private void drawBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ,
                             int color, double expand) {
            float x0 = (float) (minX - camera.x - expand);
            float y0 = (float) (minY - camera.y - expand);
            float z0 = (float) (minZ - camera.z - expand);
            float x1 = (float) (maxX - camera.x + expand);
            float y1 = (float) (maxY - camera.y + expand);
            float z1 = (float) (maxZ - camera.z + expand);
            lineRel(x0, y0, z0, x1, y0, z0, color);
            lineRel(x1, y0, z0, x1, y0, z1, color);
            lineRel(x1, y0, z1, x0, y0, z1, color);
            lineRel(x0, y0, z1, x0, y0, z0, color);
            lineRel(x0, y1, z0, x1, y1, z0, color);
            lineRel(x1, y1, z0, x1, y1, z1, color);
            lineRel(x1, y1, z1, x0, y1, z1, color);
            lineRel(x0, y1, z1, x0, y1, z0, color);
            lineRel(x0, y0, z0, x0, y1, z0, color);
            lineRel(x1, y0, z0, x1, y1, z0, color);
            lineRel(x1, y0, z1, x1, y1, z1, color);
            lineRel(x0, y0, z1, x0, y1, z1, color);
        }

        private void lineRel(float x1, float y1, float z1, float x2, float y2, float z2, int color) {
            float dx = x2 - x1;
            float dy = y2 - y1;
            float dz = z2 - z1;
            float length = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (length < 1.0E-5f) return;
            float nx = dx / length;
            float ny = dy / length;
            float nz = dz / length;
            MatrixStack.Entry entry = matrices.peek();
            consumer.vertex(entry, x1, y1, z1).color(color).normal(entry, nx, ny, nz);
            consumer.vertex(entry, x2, y2, z2).color(color).normal(entry, nx, ny, nz);
        }
    }

    /** Opens a drawing session, or returns null when the context cannot draw right now. */
    public static Pass begin(WorldRenderContext context) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || context.consumers() == null || context.matrices() == null) return null;
        Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
        Vec3d look = mc.player.getRotationVec(Compat.tickDelta());
        VertexConsumer vc = context.consumers().getBuffer(XRAY_LINES);
        return new Pass(vc, context.matrices(), cam, look);
    }

    /** Interpolated bounding box of an entity for smooth rendering between ticks. */
    public static Box lerpedBox(net.minecraft.entity.Entity e, float tickDelta) {
        Vec3d lerped = e.getLerpedPos(tickDelta);
        Vec3d now = Compat.pos(e);
        return e.getBoundingBox().offset(lerped.x - now.x, lerped.y - now.y, lerped.z - now.z);
    }
}
