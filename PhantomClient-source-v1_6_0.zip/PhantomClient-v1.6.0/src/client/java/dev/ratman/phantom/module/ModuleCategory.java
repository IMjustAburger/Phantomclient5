package dev.ratman.phantom.module;

public enum ModuleCategory {
    COMBAT("Combat", "\u2694"),
    PLAYER("Player", "\u263A"),
    MOVEMENT("Movement", "\u2725"),
    RENDER("Render", "\u25C9"),
    BASE_FINDING("Base Finding", "\u2302"),
    VISUALS("Visuals", "\u2726"),
    MISC("Misc", "\u2261"),
    MACROS("Macros", "\u25B6"),
    DONUT("Donut", "\u25CF"),
    CLIENT("Phantom Client", "\u2630");

    private final String label;
    private final String glyph;

    ModuleCategory(String label, String glyph) {
        this.label = label;
        this.glyph = glyph;
    }

    public String label() { return label; }

    public String glyph() { return glyph; }
}
