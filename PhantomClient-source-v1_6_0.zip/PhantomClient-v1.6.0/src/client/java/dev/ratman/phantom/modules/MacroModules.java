package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Compat;

/** Macros category: one-key chat / command senders and a panic switch. */
public final class MacroModules {
    private MacroModules() {}

    public static void register() {
        for (int i = 1; i <= 5; i++) ModuleManager.register(new CommandMacro(i));
        ModuleManager.register(new Panic());
    }

    static final class CommandMacro extends Module {
        final Setting.Text command;
        final Setting.Mode type = mode("type", "Send as", "Auto", "Auto", "Chat", "Command");

        CommandMacro(int index) {
            super("macro_" + index, "Macro " + index, ModuleCategory.MACROS,
                    "Sends a chat message or command when triggered (bind a key), then switches itself off.");
            command = text("command", "Message / command", index == 1 ? "/home" : "", 256);
        }

        @Override public void onEnable() {
            String m = command.get().trim();
            if (mc.getNetworkHandler() != null && !m.isEmpty()) {
                boolean cmd = type.is("Command") || (type.is("Auto") && m.startsWith("/"));
                if (cmd) mc.getNetworkHandler().sendChatCommand(m.startsWith("/") ? m.substring(1) : m);
                else mc.getNetworkHandler().sendChatMessage(m);
            }
            mc.execute(() -> setEnabled(false));
        }
    }

    static final class Panic extends Module {
        final Setting.Bool disconnect = bool("disconnect", "Also disconnect", false);

        Panic() {
            super("panic", "Panic", ModuleCategory.MACROS, "Instantly disables every module (optionally disconnects). Bind a key.");
        }

        @Override public void onEnable() {
            ModuleManager.panic();
            if (disconnect.on()) Compat.disconnect("Phantom panic");
            mc.execute(() -> setEnabled(false));
        }
    }
}
