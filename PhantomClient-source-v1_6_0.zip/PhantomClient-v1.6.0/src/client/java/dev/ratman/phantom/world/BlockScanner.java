package dev.ratman.phantom.world;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/**
 * Incremental scanner that finds blocks whose identifier matches a predicate. Chunks are scanned a
 * few per tick (never force-loaded) and the result per chunk is cached, so a wide search stays cheap.
 * Each consumer (Block ESP, Block Notifier, Netherite Finder...) owns its own scanner instance.
 */
public final class BlockScanner {
    public static final class Hit {
        public final BlockPos pos;
        public final String id;

        Hit(BlockPos pos, String id) {
            this.pos = pos;
            this.id = id;
        }
    }

    private final Map<Long, List<Hit>> cache = new HashMap<Long, List<Hit>>();
    private final Map<Long, Long> scannedAt = new HashMap<Long, Long>();
    private List<long[]> queue = new ArrayList<long[]>();
    private int queueIndex;
    private int lastChunkX = Integer.MIN_VALUE;
    private int lastChunkZ = Integer.MIN_VALUE;
    private int lastRadius = -1;
    private long generation;

    /** Call when the target set changes so old results are discarded. */
    public void invalidate() {
        cache.clear();
        scannedAt.clear();
        queue.clear();
        queueIndex = 0;
        lastChunkX = Integer.MIN_VALUE;
        generation++;
    }

    public void clear() { invalidate(); }

    public long generation() { return generation; }

    /**
     * @param chunkRadius chunk radius around the player
     * @param perTick     chunks scanned per call
     * @param rescanMs    minimum age before a chunk is re-read (picks up placed / broken blocks)
     * @param minY        lowest Y to read (inclusive)
     * @param maxY        highest Y to read (inclusive)
     */
    public void tick(MinecraftClient mc, Predicate<String> matches, int chunkRadius, int perTick,
                     long rescanMs, int minY, int maxY) {
        if (mc.world == null || mc.player == null) return;
        int pcx = mc.player.getBlockX() >> 4;
        int pcz = mc.player.getBlockZ() >> 4;
        if (pcx != lastChunkX || pcz != lastChunkZ || chunkRadius != lastRadius || queueIndex >= queue.size()) {
            rebuild(pcx, pcz, chunkRadius);
        }
        long now = System.currentTimeMillis();
        int done = 0;
        while (done < perTick && queueIndex < queue.size()) {
            long[] c = queue.get(queueIndex++);
            long key = pack((int) c[0], (int) c[1]);
            Long last = scannedAt.get(key);
            if (last != null && now - last < rescanMs) continue;
            scanChunk(mc, (int) c[0], (int) c[1], key, matches, minY, maxY);
            scannedAt.put(key, now);
            done++;
        }
    }

    private void rebuild(int cx, int cz, int radius) {
        queue = new ArrayList<long[]>();
        for (int ring = 0; ring <= radius; ring++) {
            for (int x = -ring; x <= ring; x++) {
                for (int z = -ring; z <= ring; z++) {
                    if (Math.max(Math.abs(x), Math.abs(z)) != ring) continue;
                    queue.add(new long[]{cx + x, cz + z});
                }
            }
        }
        queueIndex = 0;
        lastChunkX = cx;
        lastChunkZ = cz;
        lastRadius = radius;
        // Drop cache entries far outside the radius.
        Iterator<Map.Entry<Long, List<Hit>>> it = cache.entrySet().iterator();
        while (it.hasNext()) {
            long key = it.next().getKey();
            int x = (int) key;
            int z = (int) (key >> 32);
            if (Math.abs(x - cx) > radius + 2 || Math.abs(z - cz) > radius + 2) {
                it.remove();
                scannedAt.remove(key);
            }
        }
    }

    private void scanChunk(MinecraftClient mc, int cx, int cz, long key, Predicate<String> matches, int minY, int maxY) {
        Chunk chunk = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
        if (chunk == null) {
            cache.remove(key);
            return;
        }
        int lo = Math.max(minY, mc.world.getBottomY());
        int hi = Math.min(maxY, mc.world.getTopYInclusive());
        List<Hit> hits = new ArrayList<Hit>();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int y = lo; y <= hi; y++) {
            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    pos.set((cx << 4) + lx, y, (cz << 4) + lz);
                    BlockState state = chunk.getBlockState(pos);
                    if (state.isAir()) continue;
                    String id = idOf(state);
                    if (matches.test(id)) {
                        hits.add(new Hit(pos.toImmutable(), id));
                        if (hits.size() > 4000) break;
                    }
                }
            }
        }
        if (hits.isEmpty()) cache.remove(key);
        else cache.put(key, hits);
    }

    public static String idOf(BlockState state) {
        net.minecraft.util.Identifier id = Registries.BLOCK.getId(state.getBlock());
        return id.getNamespace().equals("minecraft") ? id.getPath() : id.toString();
    }

    public List<Hit> hits() {
        List<Hit> all = new ArrayList<Hit>();
        for (List<Hit> list : cache.values()) all.addAll(list);
        return all;
    }

    private static long pack(int x, int z) {
        return ((long) x & 0xFFFFFFFFL) | (((long) z & 0xFFFFFFFFL) << 32);
    }
}
