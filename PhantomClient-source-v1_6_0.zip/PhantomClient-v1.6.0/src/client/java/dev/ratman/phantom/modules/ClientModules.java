package dev.ratman.phantom.modules;

import dev.ratman.phantom.module.HudModule;
import dev.ratman.phantom.module.Module;
import dev.ratman.phantom.module.ModuleCategory;
import dev.ratman.phantom.module.ModuleManager;
import dev.ratman.phantom.setting.Setting;
import dev.ratman.phantom.util.Draw;
import dev.ratman.phantom.util.Theme;
import dev.ratman.phantom.world.SpawnerTracker;
import dev.ratman.phantom.world.SuspiciousChunkFinder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkStatus;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Phantom Client category: HUD elements, Radar, Region Map, Performance and Hotkeys. */
public final class ClientModules {
    private static Performance performance;

    private ClientModules() {}

    public static void register() {
        performance = new Performance();
        ModuleManager.register(new Watermark());
        ModuleManager.register(new InfoHud());
        ModuleManager.register(new ArmorHud());
        ModuleManager.register(new TargetHud());
        ModuleManager.register(new ActiveModules());
        ModuleManager.register(new Radar());
        ModuleManager.register(new RegionMap());
        ModuleManager.register(performance);
        ModuleManager.register(new Hotkeys());
    }

    public static int scansPerTick() { return performance == null ? 2 : performance.scans.i(); }

    public static long rescanMs() { return performance == null ? 4000L : Math.round(performance.rescan.d() * 1000.0); }

    /** Draws the standard HUD backing panel with a thin accent bar. */
    static void panel(DrawContext c, int x, int y, int w, int h, float opacity) {
        Draw.rrect(c, x, y, w, h, Math.max(0, Theme.cornerRadius - 1), Draw.alpha(0xFF0B0713, opacity));
        c.fill(x, y + 2, x + 2, y + h - 2, Theme.accent());
    }

    // ================================================================== Performance
    static final class Performance extends Module {
        final Setting.Num scans = num("scans", "Chunk scans per tick", 2.0, 1.0, 8.0, 1.0);
        final Setting.Num rescan = num("rescan", "Block rescan interval", 4.0, 1.0, 30.0, 1.0, " s");

        Performance() {
            super("performance", "Performance", ModuleCategory.CLIENT,
                    "Controls how much background scanning Base Finding, Block ESP and Block Notifier may do per tick.");
            alwaysOn = true;
        }

        @Override public String info() { return ""; }
    }

    // ================================================================== Hotkeys
    static final class Hotkeys extends Module {
        final Setting.KeyBind panicKey = add(new Setting.KeyBind("panic", "Panic key (disable all)", -1));
        private boolean down;

        Hotkeys() {
            super("hotkeys", "Hotkeys", ModuleCategory.CLIENT, "Global hotkeys. Module keybinds are set on each module.");
            alwaysOn = true;
        }

        @Override public void onTick() {
            int key = panicKey.get();
            if (key == -1 || mc.currentScreen != null) {
                down = false;
                return;
            }
            long w = mc.getWindow().getHandle();
            boolean now = key <= -100
                    ? GLFW.glfwGetMouseButton(w, -100 - key) == GLFW.GLFW_PRESS
                    : GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS;
            if (now && !down) ModuleManager.panic();
            down = now;
        }
    }

    // ================================================================== Watermark
    static final class Watermark extends HudModule {
        final Setting.Bool showFps = bool("fps", "Show FPS", true);
        final Setting.Num opacity = num("opacity", "Background", 0.75, 0.0, 1.0, 0.05);

        Watermark() {
            super("watermark", "Watermark", "Small client badge.", 6, 6);
            defaultOn = true;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            TextRenderer f = mc.textRenderer;
            String a = "PHANTOM";
            String b = " client";
            String fps = showFps.on() ? "  " + mc.getCurrentFps() + " fps" : "";
            int w = f.getWidth(a + b + fps) + 12;
            int h = 16;
            boxW = w;
            boxH = h;
            panel(c, x(), y(), w, h, (float) opacity.d());
            c.drawText(f, a, x() + 7, y() + 4, Theme.accent(), true);
            c.drawText(f, b, x() + 7 + f.getWidth(a), y() + 4, Theme.TEXT, true);
            if (!fps.isEmpty()) c.drawText(f, fps, x() + 7 + f.getWidth(a + b), y() + 4, Theme.MUTED, true);
        }
    }

    // ================================================================== Info HUD
    static final class InfoHud extends HudModule {
        final Setting.Bool coords = bool("coords", "Coordinates", true);
        final Setting.Bool fps = bool("fps", "FPS", true);
        final Setting.Bool cps = bool("cps", "CPS", true);
        final Setting.Bool ping = bool("ping", "Ping", true);
        final Setting.Bool speed = bool("speed", "Speed (b/s)", false);
        final Setting.Bool direction = bool("direction", "Facing", false);
        final Setting.Bool biome = bool("biome", "Biome", false);
        final Setting.Bool time = bool("time", "World time", false);
        final Setting.Num opacity = num("opacity", "Background", 0.75, 0.0, 1.0, 0.05);
        private final List<Long> clicks = new ArrayList<Long>();
        private boolean wasDown;

        InfoHud() {
            super("hud", "HUD", "Configurable information lines (coordinates, FPS, CPS, ping...).", 6, 26);
            defaultOn = true;
        }

        @Override public void onTick() {
            boolean down = mc.options.attackKey.isPressed();
            if (down && !wasDown) clicks.add(System.currentTimeMillis());
            wasDown = down;
            long now = System.currentTimeMillis();
            while (!clicks.isEmpty() && now - clicks.get(0) > 1000L) clicks.remove(0);
        }

        private List<String> lines(boolean editing) {
            List<String> out = new ArrayList<String>();
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null) {
                if (editing) {
                    out.add("XYZ 128 64 -256");
                    out.add("FPS 240   CPS 8");
                    out.add("Ping 24 ms");
                }
                return out;
            }
            if (coords.on()) out.add(String.format(Locale.ROOT, "XYZ %.1f %.1f %.1f", p.getX(), p.getY(), p.getZ()));
            StringBuilder row = new StringBuilder();
            if (fps.on()) row.append("FPS ").append(mc.getCurrentFps());
            if (cps.on()) row.append(row.length() > 0 ? "   " : "").append("CPS ").append(clicks.size());
            if (row.length() > 0) out.add(row.toString());
            if (ping.on() && mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (e != null) out.add("Ping " + e.getLatency() + " ms");
            }
            if (speed.on()) {
                net.minecraft.util.math.Vec3d v = p.getVelocity();
                out.add(String.format(Locale.ROOT, "Speed %.2f b/s", Math.sqrt(v.x * v.x + v.z * v.z) * 20.0));
            }
            if (direction.on()) out.add("Facing " + p.getHorizontalFacing().asString().toUpperCase(Locale.ROOT));
            if (biome.on()) {
                String id = mc.world.getBiome(p.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("unknown");
                out.add("Biome " + id.replace('_', ' '));
            }
            if (time.on()) {
                long t = mc.world.getTimeOfDay() % 24000L;
                long hour = (t / 1000L + 6L) % 24L;
                out.add(String.format(Locale.ROOT, "Time %02d:%02d", hour, (t % 1000L) * 60L / 1000L));
            }
            return out;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            List<String> lines = lines(editing);
            if (lines.isEmpty()) {
                boxW = 40;
                boxH = 14;
                if (editing) c.drawText(mc.textRenderer, "HUD", x() + 4, y() + 3, Theme.MUTED, true);
                return;
            }
            TextRenderer f = mc.textRenderer;
            int w = 0;
            for (String s : lines) w = Math.max(w, f.getWidth(s));
            w += 12;
            int h = lines.size() * 11 + 5;
            boxW = w;
            boxH = h;
            panel(c, x(), y(), w, h, (float) opacity.d());
            int ty = y() + 4;
            for (String s : lines) {
                c.drawText(f, s, x() + 7, ty, Theme.TEXT, true);
                ty += 11;
            }
        }
    }

    // ================================================================== Armor HUD
    static final class ArmorHud extends HudModule {
        final Setting.Bool percent = bool("percent", "Durability %", true);
        final Setting.Num opacity = num("opacity", "Background", 0.75, 0.0, 1.0, 0.05);

        ArmorHud() {
            super("armor_hud", "Armor HUD", "Shows worn armour and durability.", 6, 120);
            defaultOn = true;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            boxW = 70;
            boxH = 4 * 18 + 4;
            ClientPlayerEntity p = mc.player;
            panel(c, x(), y(), boxW, boxH, (float) opacity.d());
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (int i = 0; i < 4; i++) {
                int yy = y() + 3 + i * 18;
                if (p == null) continue;
                ItemStack s = p.getEquippedStack(slots[i]);
                if (s.isEmpty()) continue;
                c.drawItem(s, x() + 6, yy);
                if (percent.on() && s.isDamageable()) {
                    int left = s.getMaxDamage() - s.getDamage();
                    int pct = Math.round(100f * left / Math.max(1, s.getMaxDamage()));
                    int col = pct > 50 ? Theme.GOOD : (pct > 20 ? 0xFFFFD166 : Theme.BAD);
                    c.drawText(mc.textRenderer, pct + "%", x() + 26, yy + 4, col, true);
                }
            }
        }
    }

    // ================================================================== Target HUD
    static final class TargetHud extends HudModule {
        final Setting.Num opacity = num("opacity", "Background", 0.8, 0.0, 1.0, 0.05);
        private LivingEntity last;
        private long lastSeen;

        TargetHud() {
            super("target_hud", "Target HUD", "Shows the health of the mob/player you are looking at.", 6, 200);
            defaultOn = true;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            LivingEntity target = null;
            if (mc.crosshairTarget instanceof EntityHitResult) {
                Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
                if (e instanceof LivingEntity) target = (LivingEntity) e;
            }
            long now = System.currentTimeMillis();
            if (target != null) {
                last = target;
                lastSeen = now;
            } else if (last != null && now - lastSeen < 1500L && last.isAlive()) {
                target = last;
            }
            boxW = 120;
            boxH = 30;
            if (target == null && !editing) return;
            panel(c, x(), y(), boxW, boxH, (float) opacity.d());
            TextRenderer f = mc.textRenderer;
            String name = target == null ? "Target" : Draw.fit(f, target.getName().getString(), 100);
            float hp = target == null ? 20f : target.getHealth();
            float max = target == null ? 20f : Math.max(1f, target.getMaxHealth());
            c.drawText(f, name, x() + 7, y() + 4, Theme.TEXT, true);
            int barW = boxW - 14;
            c.fill(x() + 7, y() + 17, x() + 7 + barW, y() + 21, 0xFF1B1230);
            float ratio = Math.max(0f, Math.min(1f, hp / max));
            c.fill(x() + 7, y() + 17, x() + 7 + Math.round(barW * ratio), y() + 21, Draw.lerp(Theme.BAD, Theme.accent(), ratio));
            c.drawText(f, String.format(Locale.ROOT, "%.1f / %.0f", hp, max), x() + 7, y() + 22, Theme.MUTED, false);
        }
    }

    // ================================================================== Active Modules
    static final class ActiveModules extends HudModule {
        final Setting.Bool showInfo = bool("info", "Show mode info", true);
        final Setting.Num opacity = num("opacity", "Background", 0.6, 0.0, 1.0, 0.05);

        ActiveModules() {
            super("active_modules", "Active Modules", "List of enabled modules (right aligned).", 6, 6);
            defaultOn = true;
            hideFromList = true;
        }

        private int screenW() { return mc.getWindow().getScaledWidth(); }

        @Override public int x() { return screenW() - boxW - posX.i(); }

        @Override public void moveTo(int x, int y) {
            posX.set((double) Math.max(0, screenW() - boxW - x));
            posY.set((double) y);
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            TextRenderer f = mc.textRenderer;
            List<String> names = new ArrayList<String>();
            for (Module m : ModuleManager.all()) {
                if (!m.enabled() || m.hideFromList || m.alwaysOn || m instanceof HudModule) continue;
                String info = showInfo.on() ? m.info() : "";
                names.add(info.isEmpty() ? m.name : m.name + " " + info);
            }
            if (names.isEmpty() && editing) names.add("Active modules");
            Collections.sort(names, new Comparator<String>() {
                @Override public int compare(String a, String b) {
                    return Integer.compare(f.getWidth(b), f.getWidth(a));
                }
            });
            int w = 40;
            for (String s : names) w = Math.max(w, f.getWidth(s) + 12);
            boxW = w;
            boxH = Math.max(14, names.size() * 12 + 2);
            int right = x() + w;
            int yy = y();
            for (String s : names) {
                int sw = f.getWidth(s) + 10;
                Draw.rrect(c, right - sw, yy, sw, 12, 2, Draw.alpha(0xFF0B0713, (float) opacity.d() + 0.2f));
                c.fill(right - 2, yy + 1, right, yy + 11, Theme.accent());
                c.drawText(f, s, right - sw + 4, yy + 2, Theme.TEXT, true);
                yy += 12;
            }
        }
    }

    // ================================================================== Radar
    static final class Radar extends HudModule {
        final Setting.Num size = num("size", "Size", 110.0, 70.0, 220.0, 5.0, " px");
        final Setting.Num range = num("range", "Range", 48.0, 8.0, 160.0, 4.0, " blocks");
        final Setting.Bool rotate = bool("rotate", "Rotate with view", true);
        final Setting.Bool players = bool("players", "Players", true);
        final Setting.Bool hostile = bool("hostile", "Hostile mobs", true);
        final Setting.Bool passive = bool("passive", "Passive mobs", false);
        final Setting.Bool items = bool("items", "Items", false);
        final Setting.Num opacity = num("opacity", "Background", 0.75, 0.0, 1.0, 0.05);

        Radar() {
            super("radar", "Radar", "2D radar showing nearby players and mobs.", 6, 250);
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            int s = size.i();
            boxW = s;
            boxH = s;
            int x = x();
            int y = y();
            Draw.rrectBorder(c, x, y, s, s, Math.max(1, Theme.cornerRadius), Draw.alpha(0xFF0B0713, (float) opacity.d()), Theme.BORDER);
            int cx = x + s / 2;
            int cy = y + s / 2;
            c.fill(x + 2, cy, x + s - 2, cy + 1, 0x33FFFFFF);
            c.fill(cx, y + 2, cx + 1, y + s - 2, 0x33FFFFFF);
            ClientPlayerEntity p = mc.player;
            if (p != null && mc.world != null) {
                double yaw = Math.toRadians(rotate.on() ? p.getYaw() : 180.0);
                double sin = Math.sin(yaw);
                double cos = Math.cos(yaw);
                double scale = (s / 2.0 - 4) / range.d();
                for (Entity e : mc.world.getEntities()) {
                    if (e == p) continue;
                    int col;
                    if (e instanceof PlayerEntity) {
                        if (!players.on()) continue;
                        col = Theme.accent();
                    } else if (e instanceof Monster) {
                        if (!hostile.on()) continue;
                        col = Theme.BAD;
                    } else if (e instanceof LivingEntity) {
                        if (!passive.on()) continue;
                        col = Theme.GOOD;
                    } else if (e instanceof ItemEntity) {
                        if (!items.on()) continue;
                        col = 0xFF93C5FD;
                    } else {
                        continue;
                    }
                    double dx = e.getX() - p.getX();
                    double dz = e.getZ() - p.getZ();
                    // rotate so that "forward" is up
                    double rx = dx * cos + dz * sin;
                    double rz = -dx * sin + dz * cos;
                    int px = cx + (int) Math.round(rx * scale);
                    int py = cy + (int) Math.round(rz * scale);
                    if (px < x + 2 || px > x + s - 3 || py < y + 2 || py > y + s - 3) continue;
                    c.fill(px - 1, py - 1, px + 2, py + 2, col);
                }
            }
            c.fill(cx - 1, cy - 1, cx + 2, cy + 2, 0xFFFFFFFF);
            if (!rotate.on()) c.drawText(mc.textRenderer, "N", cx - 2, y + 3, Theme.MUTED, false);
        }
    }

    // ================================================================== Region Map
    static final class RegionMap extends HudModule {
        final Setting.Num size = num("size", "Size", 120.0, 80.0, 240.0, 5.0, " px");
        final Setting.Num radius = num("radius", "Radius", 14.0, 6.0, 32.0, 1.0, " chunks");
        final Setting.Bool regions = bool("regions", "Region grid", true);
        final Setting.Bool suspicious = bool("suspicious", "Suspicious chunks", true);
        final Setting.Bool spawners = bool("spawners", "Spawners", true);
        final Setting.Num opacity = num("opacity", "Background", 0.8, 0.0, 1.0, 0.05);
        private boolean[][] loaded = new boolean[0][0];
        private int gridRadius = -1;
        private int refresh;

        RegionMap() {
            super("region_map", "Region Map", "Chunk map with 32x32 region grid, remembered base chunks and spawners.", 6, 380);
        }

        @Override public void onTick() {
            if (refresh-- > 0) return;
            refresh = 10;
            int r = radius.i();
            int n = r * 2 + 1;
            boolean[][] grid = new boolean[n][n];
            int pcx = mc.player.getBlockX() >> 4;
            int pcz = mc.player.getBlockZ() >> 4;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    grid[dx + r][dz + r] = mc.world.getChunkManager().getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false) != null;
                }
            }
            loaded = grid;
            gridRadius = r;
        }

        @Override public void draw(DrawContext c, float td, boolean editing) {
            int s = size.i();
            boxW = s;
            boxH = s + 12;
            int x = x();
            int y = y();
            Draw.rrectBorder(c, x, y, s, s, Math.max(1, Theme.cornerRadius), Draw.alpha(0xFF0B0713, (float) opacity.d()), Theme.BORDER);
            ClientPlayerEntity p = mc.player;
            if (p == null || mc.world == null || gridRadius < 0) {
                c.drawText(mc.textRenderer, "Region Map", x + 6, y + 6, Theme.MUTED, true);
                return;
            }
            int r = gridRadius;
            int n = r * 2 + 1;
            double cell = (s - 2.0) / n;
            int pcx = p.getBlockX() >> 4;
            int pcz = p.getBlockZ() >> 4;
            int accent = Theme.accent();
            for (int dx = 0; dx < n && dx < loaded.length; dx++) {
                for (int dz = 0; dz < n && dz < loaded[dx].length; dz++) {
                    if (!loaded[dx][dz]) continue;
                    int px = x + 1 + (int) Math.floor(dx * cell);
                    int py = y + 1 + (int) Math.floor(dz * cell);
                    int pw = Math.max(1, (int) Math.floor((dx + 1) * cell) - (int) Math.floor(dx * cell));
                    int ph = Math.max(1, (int) Math.floor((dz + 1) * cell) - (int) Math.floor(dz * cell));
                    c.fill(px, py, px + pw - (cell > 4 ? 1 : 0), py + ph - (cell > 4 ? 1 : 0), Draw.alpha(accent, 0.28f));
                }
            }
            if (regions.on()) {
                for (int dx = -r; dx <= r + 1; dx++) {
                    int chunkX = pcx + dx;
                    if ((chunkX & 31) == 0) {
                        int px = x + 1 + (int) Math.floor((dx + r) * cell);
                        if (px > x && px < x + s) c.fill(px, y + 1, px + 1, y + s - 1, 0x66FFFFFF);
                    }
                }
                for (int dz = -r; dz <= r + 1; dz++) {
                    int chunkZ = pcz + dz;
                    if ((chunkZ & 31) == 0) {
                        int py = y + 1 + (int) Math.floor((dz + r) * cell);
                        if (py > y && py < y + s) c.fill(x + 1, py, x + s - 1, py + 1, 0x66FFFFFF);
                    }
                }
            }
            if (suspicious.on()) {
                SuspiciousChunkFinder.Params params = BaseModules.chunkParams();
                if (params != null) {
                    for (int[] ch : SuspiciousChunkFinder.suspiciousChunks(params)) {
                        int dx = ch[0] - pcx + r;
                        int dz = ch[1] - pcz + r;
                        if (dx < 0 || dz < 0 || dx >= n || dz >= n) continue;
                        int px = x + 1 + (int) Math.floor(dx * cell);
                        int py = y + 1 + (int) Math.floor(dz * cell);
                        int sz = Math.max(2, (int) Math.floor(cell));
                        c.fill(px, py, px + sz, py + sz, 0xFFC8A2FF);
                    }
                }
            }
            if (spawners.on()) {
                for (BlockPos sp : SpawnerTracker.known()) {
                    int dx = (sp.getX() >> 4) - pcx + r;
                    int dz = (sp.getZ() >> 4) - pcz + r;
                    if (dx < 0 || dz < 0 || dx >= n || dz >= n) continue;
                    int px = x + 1 + (int) Math.floor((dx + 0.5) * cell);
                    int py = y + 1 + (int) Math.floor((dz + 0.5) * cell);
                    c.fill(px - 1, py - 1, px + 2, py + 2, 0xFFFF2D2D);
                }
            }
            double fx = (p.getX() / 16.0 - pcx + r) * cell;
            double fz = (p.getZ() / 16.0 - pcz + r) * cell;
            int mx = x + 1 + (int) Math.round(fx);
            int my = y + 1 + (int) Math.round(fz);
            c.fill(mx - 1, my - 1, mx + 2, my + 2, 0xFFFFFFFF);
            double yaw = Math.toRadians(p.getYaw());
            int lx = mx + (int) Math.round(-Math.sin(yaw) * 5);
            int ly = my + (int) Math.round(Math.cos(yaw) * 5);
            c.fill(lx, ly, lx + 1, ly + 1, 0xFFFFFFFF);
            String label = "r." + Math.floorDiv(pcx, 32) + "." + Math.floorDiv(pcz, 32);
            c.drawText(mc.textRenderer, label, x + 2, y + s + 2, Theme.MUTED, false);
        }
    }
}
