package dev.phantom.gradle;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Small project-local Gradle launcher. It bootstraps the pinned official Gradle distribution,
 * validates its SHA-256 digest, and then forwards every argument to Gradle.
 */
public final class GradleBootstrap {
    private static final String VERSION = "9.8.2";
    private static final String DISTRIBUTION = "gradle-" + VERSION + "-bin.zip";
    private static final String DEFAULT_URL = "https://services.gradle.org/distributions/" + DISTRIBUTION;
    private static final String DEFAULT_SHA256 =
            "21bd5da2de49b642904077f38c0efdc7778e92b3ed0889392dca61b97e389607";

    private GradleBootstrap() {}

    public static void main(String[] args) {
        try {
            if (Arrays.asList(args).contains("--bootstrap-info")) {
                System.out.println("Phantom Client Gradle bootstrap");
                System.out.println("Gradle version: " + VERSION);
                System.out.println("Distribution: " + DEFAULT_URL);
                System.out.println("SHA-256: " + DEFAULT_SHA256);
                System.out.println("Java runtime: " + Runtime.version());
                return;
            }
            requireJava21();
            Path projectDir = Path.of(System.getProperty("phantom.projectDir", ".")).toAbsolutePath().normalize();
            Properties wrapper = readWrapperProperties(projectDir);
            String distributionUrl = wrapper.getProperty("distributionUrl", DEFAULT_URL)
                    .replace("\\:", ":");
            String expectedSha = wrapper.getProperty("distributionSha256Sum", DEFAULT_SHA256).trim()
                    .toLowerCase(Locale.ROOT);
            if (!expectedSha.matches("[0-9a-f]{64}")) {
                throw new IllegalStateException("Invalid distributionSha256Sum in gradle-wrapper.properties");
            }

            String fileName = distributionUrl.substring(distributionUrl.lastIndexOf('/') + 1);
            if (!fileName.endsWith(".zip")) {
                throw new IllegalStateException("Gradle distribution URL must end in .zip");
            }
            String versionDirectory = fileName.substring(0, fileName.length() - 4);
            Path gradleUserHome = gradleUserHome();
            Path distributionHome = gradleUserHome.resolve("wrapper/dists")
                    .resolve(versionDirectory).resolve("phantom-client-bootstrap");
            Path gradleHome = distributionHome.resolve("gradle-" + VERSION);
            Path executable = gradleExecutable(gradleHome);

            if (!Files.isRegularFile(executable)) {
                Files.createDirectories(distributionHome);
                Path archive = distributionHome.resolve(fileName);
                downloadDistribution(distributionUrl, archive, expectedSha);
                extractDistribution(archive, distributionHome);
                Files.deleteIfExists(archive);
                executable = gradleExecutable(gradleHome);
            }
            if (!Files.isRegularFile(executable)) {
                throw new IOException("Downloaded Gradle archive did not contain " + executable);
            }
            makeExecutable(executable);
            runGradle(executable, projectDir, args);
        } catch (Exception exception) {
            String message = exception.getMessage();
            System.err.println("[Phantom Gradle] " + (message == null || message.isBlank()
                    ? exception.getClass().getSimpleName() : message));
            System.err.println("Install a Java 21 JDK and ensure this device can reach services.gradle.org.");
            System.exit(1);
        }
    }

    private static void requireJava21() {
        int feature = Runtime.version().feature();
        if (feature < 21) {
            throw new IllegalStateException("Java 21 or newer is required; found Java " + feature);
        }
    }

    private static Properties readWrapperProperties(Path projectDir) throws IOException {
        Path propertiesFile = projectDir.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propertiesFile)) {
            throw new IOException("Missing " + propertiesFile);
        }
        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(propertiesFile)) {
            properties.load(input);
        }
        return properties;
    }

    private static Path gradleUserHome() {
        String configured = System.getenv("GRADLE_USER_HOME");
        if (configured != null && !configured.isBlank()) return Path.of(configured).toAbsolutePath();
        return Path.of(System.getProperty("user.home"), ".gradle");
    }

    private static Path gradleExecutable(Path gradleHome) {
        String executable = isWindows() ? "gradle.bat" : "gradle";
        return gradleHome.resolve("bin").resolve(executable);
    }

    private static void downloadDistribution(String url, Path archive, String expectedSha) throws Exception {
        Path partial = archive.resolveSibling(archive.getFileName() + ".part");
        Files.deleteIfExists(partial);
        System.out.println("Downloading Gradle " + VERSION + " from the official Gradle distribution service...");
        HttpClient client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(30))
                .build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofMinutes(30))
                .header("User-Agent", "PhantomClient-GradleBootstrap/1.0")
                .GET()
                .build();
        HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(partial));
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            Files.deleteIfExists(partial);
            throw new IOException("Gradle download failed with HTTP " + response.statusCode());
        }
        String actualSha = sha256(partial);
        if (!MessageDigest.isEqual(expectedSha.getBytes(java.nio.charset.StandardCharsets.US_ASCII),
                actualSha.getBytes(java.nio.charset.StandardCharsets.US_ASCII))) {
            Files.deleteIfExists(partial);
            throw new IOException("Gradle distribution checksum mismatch; refusing to run it");
        }
        Files.move(partial, archive, StandardCopyOption.REPLACE_EXISTING);
    }

    private static String sha256(Path file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = Files.newInputStream(file)) {
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = input.read(buffer)) >= 0) {
                if (read > 0) digest.update(buffer, 0, read);
            }
        }
        return HexFormat.of().formatHex(digest.digest());
    }

    private static void extractDistribution(Path archive, Path targetDirectory) throws IOException {
        Path normalizedRoot = targetDirectory.toAbsolutePath().normalize();
        System.out.println("Verifying and extracting Gradle " + VERSION + "...");
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
            ZipEntry entry;
            byte[] buffer = new byte[64 * 1024];
            while ((entry = zip.getNextEntry()) != null) {
                Path output = normalizedRoot.resolve(entry.getName()).normalize();
                if (!output.startsWith(normalizedRoot)) {
                    throw new IOException("Unsafe path in Gradle archive: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Files.createDirectories(output.getParent());
                    try (var out = Files.newOutputStream(output)) {
                        int read;
                        while ((read = zip.read(buffer)) >= 0) {
                            if (read > 0) out.write(buffer, 0, read);
                        }
                    }
                }
                zip.closeEntry();
            }
        }
    }

    private static void makeExecutable(Path executable) {
        if (isWindows()) return;
        try {
            executable.toFile().setExecutable(true, false);
        } catch (SecurityException ignored) {
            // The OS may already permit execution or may not expose POSIX attributes.
        }
    }

    private static void runGradle(Path executable, Path projectDir, String[] args) throws Exception {
        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/c");
            command.add("\"" + executable + "\"");
        } else {
            command.add(executable.toString());
        }
        command.addAll(Arrays.asList(args));
        Process process = new ProcessBuilder(command)
                .directory(projectDir.toFile())
                .inheritIO()
                .start();
        int exitCode = process.waitFor();
        if (exitCode != 0) System.exit(exitCode);
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }
}
